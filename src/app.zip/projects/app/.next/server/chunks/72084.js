"use strict";exports.id=72084,exports.ids=[72084],exports.modules={95336:(e,t,a)=>{a.d(t,{C:()=>l,K:()=>o});let l=[{title:"标准模板",desc:"标准提示词，用于结构不固定的知识库。",value:`{{q}}
{{a}}`},{title:"问答模板",desc:"适合 QA 问答结构的知识库，可以让AI较为严格的按预设内容回答",value:`<Question>
{{q}}
</Question>
<Answer>
{{a}}
</Answer>`},{title:"标准严格模板",desc:"在标准模板基础上，对模型的回答做更严格的要求。",value:`{{q}}
{{a}}`},{title:"严格问答模板",desc:"在问答模板基础上，对模型的回答做更严格的要求。",value:`<Question>
{{q}}
</Question>
<Answer>
{{a}}
</Answer>`}],o=[{title:"标准模板",desc:"",value:`使用 <Data></Data> 标记中的内容作为你的知识:

<Data>
{{quote}}
</Data>

回答要求：
- 如果你不清楚答案，你需要澄清。
- 避免提及你是从 <Data></Data> 获取的知识。
- 保持答案与 <Data></Data> 中描述的一致。
- 使用 Markdown 语法优化回答格式。
- 使用与问题相同的语言回答。

问题:"""{{question}}"""`},{title:"问答模板",desc:"",value:`使用 <QA></QA> 标记中的问答对进行回答。

<QA>
{{quote}}
</QA>

回答要求：
- 选择其中一个或多个问答对进行回答。
- 回答的内容应尽可能与 <答案></答案> 中的内容一致。
- 如果没有相关的问答对，你需要澄清。
- 避免提及你是从 QA 获取的知识，只需要回复答案。

问题:"""{{question}}"""`},{title:"标准严格模板",desc:"",value:`忘记你已有的知识，仅使用 <Data></Data> 标记中的内容作为你的知识:

<Data>
{{quote}}
</Data>

思考流程：
1. 判断问题是否与 <Data></Data> 标记中的内容有关。
2. 如果有关，你按下面的要求回答。
3. 如果无关，你直接拒绝回答本次问题。

回答要求：
- 避免提及你是从 <Data></Data> 获取的知识。
- 保持答案与 <Data></Data> 中描述的一致。
- 使用 Markdown 语法优化回答格式。
- 使用与问题相同的语言回答。

问题:"""{{question}}"""`},{title:"严格问答模板",desc:"",value:`忘记你已有的知识，仅使用 <QA></QA> 标记中的问答对进行回答。

<QA>
{{quote}}
</QA>}

思考流程：
1. 判断问题是否与 <QA></QA> 标记中的内容有关。
2. 如果无关，你直接拒绝回答本次问题。
3. 判断是否有相近或相同的问题。
4. 如果有相同的问题，直接输出对应答案。
5. 如果只有相近的问题，请把相近的问题和答案一起输出。

最后，避免提及你是从 QA 获取的知识，只需要回复答案。

问题:"""{{question}}"""`}]},81859:(e,t,a)=>{a.a(e,async(e,l)=>{try{a.d(t,{Z:()=>u});var o=a(20997),i=a(16689),r=a(46998),s=a(22210),n=e([r,s]);[r,s]=n.then?(await n)():n;let u=({title:e,templates:t,onClose:a,onSuccess:l})=>{let n=(0,s.useTheme)(),[u,p]=(0,i.useState)();return(0,o.jsxs)(r.Z,{isOpen:!0,title:e,onClose:a,iconSrc:"/imgs/modal/prompt.svg",children:[o.jsx(s.ModalBody,{h:"100%",w:"600px",maxW:"90vw",overflowY:"auto",children:o.jsx(s.Grid,{gridTemplateColumns:["1fr","1fr 1fr"],gridGap:4,children:t.map(e=>(0,o.jsxs)(s.Box,{border:n.borders.base,py:2,px:2,borderRadius:"md",cursor:"pointer",...e.title===u?.title?{bg:"primary.50"}:{},onClick:()=>p(e),children:[o.jsx(s.Box,{children:e.title}),o.jsx(s.Box,{color:"myGray.600",fontSize:"sm",whiteSpace:"pre-wrap",children:e.desc})]},e.title))})}),o.jsx(s.ModalFooter,{children:o.jsx(s.Button,{disabled:!u,onClick:()=>{u&&(l(u),a())},children:"确认选择"})})]})};l()}catch(e){l(e)}})},72084:(e,t,a)=>{a.a(e,async(e,l)=>{try{a.r(t),a.d(t,{default:()=>q});var o=a(20997),i=a(16689),r=a.n(i),s=a(22210),n=a(51324),u=a(46998),p=a(45641),c=a(11377),d=a(14466),m=a(30200),x=a(95336),h=a(86134),v=a(38731),y=a(81859),Q=a(1450),b=e([s,n,u,p,m,h,v,y]);[s,n,u,p,m,h,v,y]=b.then?(await b)():b;let q=r().memo(({inputs:e=[],moduleId:t})=>{let{t:a}=(0,c.useTranslation)(),{isOpen:l,onOpen:r,onClose:b}=(0,s.useDisclosure)(),{nodes:q}=(0,n.Ur)(),{watch:j,setValue:k,handleSubmit:f}=(0,p.useForm)({defaultValues:{quoteTemplate:e.find(e=>"quoteTemplate"===e.key)?.value||"",quotePrompt:e.find(e=>"quotePrompt"===e.key)?.value||""}}),C=j("quoteTemplate"),D=j("quotePrompt"),w=(0,i.useMemo)(()=>{let t=(0,d.QL)(d.OI(d.yx(q.map(e=>e.data)))?.variableModules||[]),l=(0,d.QL)(e.filter(e=>e.edit).map(e=>({key:e.key,label:e.label}))),o=[{key:"cTime",label:a("core.module.http.Current time")}];return[...t,...l,...o]},[e,a]),[A,M]=(0,i.useState)(),S=[{key:"q",label:"q",icon:"core/app/simpleMode/variable"},{key:"a",label:"a",icon:"core/app/simpleMode/variable"},{key:"source",label:a("core.dataset.search.Source name"),icon:"core/app/simpleMode/variable"},{key:"sourceId",label:a("core.dataset.search.Source id"),icon:"core/app/simpleMode/variable"},{key:"index",label:a("core.dataset.search.Quote index"),icon:"core/app/simpleMode/variable"},...w],T=[{key:"quote",label:a("core.app.Quote templates"),icon:"core/app/simpleMode/variable"},{key:"question",label:a("core.module.input.label.user question"),icon:"core/app/simpleMode/variable"},...w],B={fontSize:["sm","md"]};return(0,o.jsxs)(o.Fragment,{children:[o.jsx(s.Button,{variant:"whitePrimary",size:"sm",onClick:r,children:a("core.module.Setting quote prompt")}),(0,o.jsxs)(u.Z,{isOpen:l,iconSrc:"modal/edit",title:a("core.module.Quote prompt setting"),w:"600px",children:[(0,o.jsxs)(s.ModalBody,{children:[(0,o.jsxs)(s.Box,{children:[(0,o.jsxs)(s.Flex,{...B,mb:1,children:[a("core.app.Quote templates"),o.jsx(m.Z,{label:a("template.Quote Content Tip",{default:x.C[0].value}),forceShow:!0,children:o.jsx(h.QuestionOutlineIcon,{display:["none","inline"],ml:1})}),o.jsx(s.Box,{flex:1}),o.jsx(s.Box,{color:"primary.500",cursor:"pointer",onClick:()=>M({title:a("core.app.Select quote template"),templates:x.C}),children:a("common.Select template")})]}),o.jsx(v.Z,{variables:S,h:160,title:a("core.app.Quote templates"),placeholder:a("template.Quote Content Tip",{default:x.C[0].value}),value:C,onChange:e=>{k("quoteTemplate",e)}})]}),(0,o.jsxs)(s.Box,{mt:4,children:[(0,o.jsxs)(s.Flex,{...B,mb:1,children:[a("core.app.Quote prompt"),o.jsx(m.Z,{label:a("template.Quote Prompt Tip",{default:x.K[0].value}),forceShow:!0,children:o.jsx(h.QuestionOutlineIcon,{display:["none","inline"],ml:1})})]}),o.jsx(v.Z,{variables:T,title:a("core.app.Quote prompt"),h:280,placeholder:a("template.Quote Prompt Tip",{default:x.K[0].value}),value:D,onChange:e=>{k("quotePrompt",e)}})]})]}),(0,o.jsxs)(s.ModalFooter,{children:[o.jsx(s.Button,{variant:"whiteBase",mr:2,onClick:b,children:a("common.Close")}),o.jsx(s.Button,{onClick:f(a=>{let l=e.find(e=>e.key===Q.pY.aiChatQuoteTemplate),o=e.find(e=>e.key===Q.pY.aiChatQuotePrompt);l&&(0,n.IY)({moduleId:t,type:"updateInput",key:l.key,value:{...l,value:a.quoteTemplate}}),o&&(0,n.IY)({moduleId:t,type:"updateInput",key:o.key,value:{...o,value:a.quotePrompt}}),b()}),children:a("common.Confirm")})]})]}),!!A&&o.jsx(y.Z,{title:A.title,templates:A.templates,onClose:()=>M(void 0),onSuccess:e=>{let t=e.value,a=x.K.find(t=>t.title===e.title)?.value;k("quoteTemplate",t),k("quotePrompt",a)}})]})});l()}catch(e){l(e)}})}};