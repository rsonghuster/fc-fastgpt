"use strict";exports.id=6982,exports.ids=[6982],exports.modules={78245:(e,t,r)=>{r.d(t,{n:()=>l,o:()=>i});var n=r(30899),a=r(44315);let i=e=>{if(0===(e=e.filter(e=>e.list.length>0)).length)return[];if(1===e.length)return e[0].list;let t=new Map;e.forEach(e=>{let r=e.k;e.list.forEach((e,n)=>{let a=1/(r+(n+1)),i=t.get(e.id);if(i){let r=[...i.score];for(let t of e.score){let e=r.find(e=>e.type===t.type);e?e.value=Math.max(e.value,t.value):r.push(t)}t.set(e.id,{...i,score:r,rrfScore:i.rrfScore+a})}else t.set(e.id,{...e,rrfScore:a})})});let r=Array.from(t.values()),n=r.sort((e,t)=>t.rrfScore-e.rrfScore);return n.map((e,t)=>{let r=e.score.find(e=>e.type===a.ds.rrf);return r?(r.value=e.rrfScore,r.index=t):e.score.push({type:a.ds.rrf,value:e.rrfScore,index:t}),delete e.rrfScore,e})},l=(e,t)=>{let r=[],a=0;for(let i=0;i<e.length;i++){let l=e[i];if((a+=(0,n.BM)(l.q+l.a))>t+500||(r.push(l),a>t))break}return 0===r.length?e.slice(0,1):r}},71826:(e,t,r)=>{r.a(e,async(e,n)=>{try{r.d(t,{a4:()=>o});var a=r(57020),i=r(99648),l=e([i]);i=(l.then?(await l)():l)[0];let s=i.default.create({timeout:6e4,headers:{"content-type":"application/json","Cache-Control":"no-cache"}});function o(e,t={},r={}){return function(e,t,r,n){for(let e in t)(null===t[e]||void 0===t[e])&&delete t[e];return s.request({baseURL:`http://${a.wm}`,url:e,method:n,data:["POST","PUT"].includes(n)?t:null,params:["POST","PUT"].includes(n)?null:t,...r}).then(e=>{var t;return t=e.data,void 0===t?(console.log("error->",t,"data is empty"),Promise.reject("服务器异常")):t?.code&&(t.code<200||t.code>=400)?Promise.reject(t):t}).catch(e=>e?"string"==typeof e?Promise.reject({message:e}):e?.response?.data?Promise.reject(e?.response?.data):Promise.reject(e):Promise.reject({message:"未知错误"}))}(e,t,r,"POST")}s.interceptors.request.use(function(e){return e},e=>Promise.reject(e)),s.interceptors.response.use(function(e){return e},e=>Promise.reject(e)),n()}catch(e){n(e)}})},99476:(e,t,r)=>{r.a(e,async(e,n)=>{try{r.d(t,{H:()=>c});var a=r(76420),i=r(46275),l=r(30899),o=e([a]);a=(o.then?(await o)():o)[0];let s=`作为一个向量检索助手，你的任务是结合历史记录，从不同角度，为“原问题”生成个不同版本的“检索词”，从而提高向量检索的语义丰富度，提高向量检索的精度。生成的问题要求指向对象清晰明确，并与“原问题语言相同”。例如：
历史记录: 
"""
"""
原问题: 介绍下剧情。
检索词: ["介绍下故事的背景和主要人物。","故事的主题是什么？","剧情是是如何发展的？"]
----------------
历史记录: 
"""
Q: 对话背景。
A: 当前对话是关于 Nginx 的介绍和使用等。
"""
原问题: 怎么下载
检索词: ["Nginx 如何下载？","下载 Nginx 需要什么条件？","有哪些渠道可以下载 Nginx？"]
----------------
历史记录: 
"""
Q: 对话背景。
A: 当前对话是关于 Nginx 的介绍和使用等。
Q: 报错 "no connection"
A: 报错"no connection"可能是因为……
"""
原问题: 怎么解决
检索词: ["Nginx报错"no connection"如何解决？","造成'no connection'报错的原因。","Nginx提示'no connection'，要怎么办？"]
----------------
历史记录: 
"""
Q: 护产假多少天?
A: 护产假的天数根据员工所在的城市而定。请提供您所在的城市，以便我回答您的问题。
"""
原问题: 沈阳
检索词: ["沈阳的护产假多少天？"]
----------------
历史记录: 
"""
Q: 作者是谁？
A: FastGPT 的作者是 labring。
"""
原问题: Tell me about him
检索词: ["Introduce labring, the author of FastGPT." ," Background information on author labring." "," Why does labring do FastGPT?"]
----------------
历史记录:
"""
Q: 对话背景。
A: 关于 FatGPT 的介绍和使用等问题。
"""
原问题: 你好。
检索词: ["你好"]
----------------
历史记录:
"""
Q: FastGPT 如何收费？
A: FastGPT 收费可以参考……
"""
原问题: 你知道 laf 么？
检索词: ["laf是什么？","如何使用laf？","laf的介绍。"]
----------------
历史记录:
"""
Q: FastGPT 的优势
A: 1. 开源
   2. 简便
   3. 扩展性强
"""
原问题: 介绍下第2点。
检索词: ["介绍下 FastGPT 简便的优势", "FastGPT 为什么使用起来简便？","FastGPT的有哪些简便的功能？"]。
----------------
历史记录:
"""
Q: 什么是 FastGPT？
A: FastGPT 是一个 RAG 平台。
Q: 什么是 Laf？
A: Laf 是一个云函数开发平台。
"""
原问题: 它们有什么关系？
检索词: ["FastGPT和Laf有什么关系？","FastGPT的RAG是用Laf实现的么？"]
----------------
历史记录:
"""
{{histories}}
"""
原问题: {{query}}
检索词: `,c=async({chatBg:e,query:t,histories:r=[],model:n})=>{let o=e?`Q: 对话背景。
A: ${e}
`:"",c=r.map(e=>{let t="Human"===e.obj?"Q":"A";return`${t}: ${e.value}`}).join("\n"),d=`${o}${c}`.trim(),u=(0,i.c)({timeout:48e4}),m=[{role:"user",content:(0,a.Fm)(s,{query:`${t}`,histories:d})}],f=await u.chat.completions.create({model:n,temperature:.01,messages:m,stream:!1}),h=f.choices?.[0]?.message?.content||"";if(!h)return{rawQuery:t,extensionQueries:[],model:n,tokens:0};h=h.replace(/\\"/g,'"');try{let e=JSON.parse(h);return{rawQuery:t,extensionQueries:Array.isArray(e)?e:[],model:n,tokens:(0,l.et)(m)}}catch(e){return console.log(e),{rawQuery:t,extensionQueries:[],model:n,tokens:0}}};n()}catch(e){n(e)}})},83902:(e,t,r)=>{r.a(e,async(e,n)=>{try{r.d(t,{n:()=>l});var a=r(71826),i=e([a]);function l({query:e,documents:t}){let r=global.reRankModels[0];if(!r||!r?.requestUrl)return Promise.reject("no rerank model");let n=Date.now();return(0,a.a4)(r.requestUrl,{model:r.model,query:e,documents:t.map(e=>e.text)},{headers:{Authorization:`Bearer ${r.requestAuth}`},timeout:3e4}).then(e=>(console.log("rerank time:",Date.now()-n),e?.results?.map(e=>({id:t[e.index].id,score:e.relevance_score})))).catch(e=>(console.log("rerank error:",e),[]))}a=(i.then?(await i)():i)[0],n()}catch(e){n(e)}})},92359:(e,t,r)=>{r.a(e,async(e,n)=>{try{r.d(t,{n:()=>g});var a=r(44315),i=r(16150),l=r(20801),o=r(54176),s=r(72767),c=r(83287),d=r(83902),u=r(30899),m=r(78245),f=r(76420),h=r(92016),p=e([d,f]);async function g(e){let{teamId:t,reRankQuery:r,queries:n,model:p,similarity:g=0,limit:y,searchMode:x=a.wq.embedding,usingReRank:w=!1,datasetIds:I=[]}=e;x=a.Nz[x]?x:a.wq.embedding,w=w&&global.reRankModels.length>0,y<50&&(y=1500);let k=new Set,P=!1,S=async({query:e,limit:r})=>{let{vectors:n,tokens:c}=await (0,l.r)({model:(0,o.BA)(p),input:e,type:"query"}),{results:d}=await (0,i.MX)({vectors:n,limit:r,datasetIds:I,efSearch:global.systemEnv?.pgHNSWEfSearch}),u=await s.o.find({teamId:t,datasetId:{$in:I},"indexes.dataId":{$in:d.map(e=>e.id?.trim())}},"datasetId collectionId q a chunkIndex indexes").populate("collectionId","name fileId rawLink").lean(),m=u.map(e=>{let t=e.indexes.map(e=>e.dataId),r=d.find(e=>t.includes(e.id));return{...e,score:r?.score||0}});m.sort((e,t)=>t.score-e.score);let f=m.map((e,t)=>{e.collectionId||console.log("Collection is not found",e);let r={id:String(e._id),q:e.q,a:e.a,chunkIndex:e.chunkIndex,datasetId:String(e.datasetId),collectionId:String(e.collectionId?._id),sourceName:e.collectionId?.name||"",sourceId:e.collectionId?.fileId||e.collectionId?.rawLink,score:[{type:a.ds.embedding,value:e.score,index:t}]};return r}).filter(e=>null!==e);return{embeddingRecallResults:f,tokens:c}},T=async({query:e,limit:r})=>{if(0===r)return{fullTextRecallResults:[],tokenLen:0};let n=(await Promise.all(I.map(n=>s.o.find({teamId:t,datasetId:n,$text:{$search:(0,h.P)({text:e})}},{score:{$meta:"textScore"},_id:1,datasetId:1,collectionId:1,q:1,a:1,chunkIndex:1}).sort({score:{$meta:"textScore"}}).limit(r).lean()))).flat();n.sort((e,t)=>t.score-e.score),n.slice(0,r);let i=await c.w.find({_id:{$in:n.map(e=>e.collectionId)}},"_id name fileId rawLink");return{fullTextRecallResults:n.map((e,t)=>{let r=i.find(t=>String(t._id)===String(e.collectionId));return{id:String(e._id),datasetId:String(e.datasetId),collectionId:String(e.collectionId),sourceName:r?.name||"",sourceId:r?.fileId||r?.rawLink,q:e.q,a:e.a,chunkIndex:e.chunkIndex,indexes:e.indexes,score:[{type:a.ds.fullText,value:e.score,index:t}]}}),tokenLen:0}},q=async({data:e,query:t})=>{try{let r=await (0,d.n)({query:t,documents:e.map(e=>({id:e.id,text:`${e.q}
${e.a}`}))});if(0===r.length)return w=!1,[];let n=r.map((t,r)=>{let n=e.find(e=>e.id===t.id);if(!n)return null;let i=t.score||0;return{...n,score:[{type:a.ds.reRank,value:i,index:r}]}}).filter(Boolean);return n}catch(e){return w=!1,[]}},$=async({embeddingLimit:e,fullTextLimit:t})=>{let r=[],a=[],i=0;await Promise.all(n.map(async n=>{let[{tokens:l,embeddingRecallResults:o},{fullTextRecallResults:s}]=await Promise.all([S({query:n,limit:e}),T({query:n,limit:t})]);i+=l,r.push(o),a.push(s)}));let l=(0,m.o)(r.map(e=>({k:60,list:e}))).slice(0,e),o=(0,m.o)(a.map(e=>({k:60,list:e}))).slice(0,t);return{tokens:i,embeddingRecallResults:l,fullTextRecallResults:o}},{embeddingLimit:b,fullTextLimit:v}=x===a.wq.embedding?{embeddingLimit:150,fullTextLimit:0}:x===a.wq.fullTextRecall?{embeddingLimit:0,fullTextLimit:150}:{embeddingLimit:100,fullTextLimit:80},{embeddingRecallResults:A,fullTextRecallResults:Q,tokens:L}=await $({embeddingLimit:b,fullTextLimit:v}),R=await (async()=>{if(!w)return[];k=new Set(A.map(e=>e.id));let e=A.concat(Q.filter(e=>!k.has(e.id)));k=new Set;let t=e.filter(e=>{let t=(0,f.ck)(`${e.q}${e.a}`.replace(/[^\p{L}\p{N}]/gu,""));return!k.has(t)&&(k.add(t),!0)});return q({query:r,data:t})})(),j=(0,m.o)([{k:60,list:A},{k:60,list:Q},{k:58,list:R}]);k=new Set;let G=j.filter(e=>{let t=(0,f.ck)(`${e.q}${e.a}`.replace(/[^\p{L}\p{N}]/gu,""));return!k.has(t)&&(k.add(t),!0)}),N=w?(P=!0,G.filter(e=>{let t=e.score.find(e=>e.type===a.ds.reRank);return!t||!(t.value<g)})):x===a.wq.embedding?(P=!0,G.filter(e=>{let t=e.score.find(e=>e.type===a.ds.embedding);return!t||!(t.value<g)})):G;return{searchRes:((e,t)=>{let r=[],n=0;for(let a=0;a<e.length;a++){let i=e[a];if((n+=(0,u.BM)(i.q+i.a))>t+500||(r.push(i),n>t))break}return 0===r.length?e.slice(0,1):r})(N,y),tokens:L,searchMode:x,limit:y,similarity:g,usingReRank:w,usingSimilarityFilter:P}}[d,f]=p.then?(await p)():p,n()}catch(e){n(e)}})},79732:(e,t,r)=>{r.a(e,async(e,n)=>{try{r.d(t,{g:()=>o});var a=r(99476),i=r(76420),l=e([a,i]);[a,i]=l.then?(await l)():l;let o=async({query:e,extensionModel:t,extensionBg:r="",histories:n=[]})=>{let l=e=>{let t=new Set,r=e.filter(e=>{let r=(0,i.ck)(e.replace(/[^\p{L}\p{N}]/gu,""));return!t.has(r)&&(t.add(r),!0)});return r},{queries:o,rewriteQuery:s,alreadyExtension:c}=(()=>{let t=n.length>0?`${n.map(e=>`${e.obj}: ${e.value}`).join("\n")}
  Human: ${e}
  `:e;try{let r=JSON.parse(e),n=Array.isArray(r)?l(r):[e],a=Array.isArray(r);return{queries:n,rewriteQuery:a?n.join("\n"):t,alreadyExtension:a}}catch(r){return{queries:[e],rewriteQuery:t,alreadyExtension:!1}}})(),d=await (async()=>{if(!t||c)return;let i=await (0,a.H)({chatBg:r,query:e,histories:n,model:t.model});if(i.extensionQueries?.length!==0)return i})();return d&&(s=(o=l(o.concat(d.extensionQueries))).join("\n")),{concatQueries:o,rewriteQuery:s,aiExtensionResult:d}};n()}catch(e){n(e)}})}};