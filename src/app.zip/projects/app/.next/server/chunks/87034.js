"use strict";exports.id=87034,exports.ids=[87034],exports.modules={50117:(e,t,i)=>{i.d(t,{c5:()=>o});let o={description:`<Context></Context> 标记中是一段文本，学习和分析它，并整理学习成果：
- 提出问题并给出每个问题的答案。
- 答案需详细完整，尽可能保留原文描述。
- 答案可以包含普通文字、链接、代码、表格、公示、媒体链接等 Markdown 元素。
- 最多提出 30 个问题。
`,fixedText:`请按以下格式整理学习成果:
<Context>
文本
</Context>
Q1: 问题。
A1: 答案。
Q2:
A2:

------

我们开始吧!

<Context>
{{text}}
<Context/>
`}},87034:(e,t,i)=>{i.a(e,async(e,o)=>{try{i.r(t),i.d(t,{default:()=>l,useImportStore:()=>k});var n=i(20997),u=i(16689),a=i.n(u),r=i(63809),c=i(11377),h=i(50117),s=i(45641),p=i(22968),d=e([s]);s=(d.then?(await d)():d)[0];let m=(0,u.createContext)({processParamsForm:{},sources:[],setSources:function(e){throw Error("Function not implemented.")},maxChunkSize:0,minChunkSize:0,showChunkInput:!1,showPromptInput:!1,chunkSizeField:"embeddingChunkSize",chunkSize:0,chunkOverlapRatio:0,priceTip:"",uploadRate:50,importSource:r.iR.fileLocal}),k=()=>(0,u.useContext)(m),l=a().memo(({importSource:e,dataset:t,parentId:i,children:o})=>{let a=t.vectorModel,d=t.agentModel,k=(0,s.useForm)({defaultValues:{mode:r.g0.chunk,way:p.h.auto,embeddingChunkSize:a?.defaultToken||512,customSplitChar:"",qaPrompt:h.c5.description,webSelector:""}}),{t:l}=(0,c.useTranslation)(),[S,C]=(0,u.useState)([]),P=k.watch("mode"),z=k.watch("way"),x=k.watch("embeddingChunkSize"),w=k.watch("customSplitChar"),T={[r.g0.auto]:{chunkOverlapRatio:.2,maxChunkSize:2048,minChunkSize:100,autoChunkSize:a?.defaultToken?a?.defaultToken*2:1024,chunkSize:a?.defaultToken?a?.defaultToken*2:1024,showChunkInput:!1,showPromptInput:!1,charsPointsPrice:d.charsPointsPrice,priceTip:l("core.dataset.import.Auto mode Estimated Price Tips",{price:d.charsPointsPrice}),uploadRate:100},[r.g0.chunk]:{chunkSizeField:"embeddingChunkSize",chunkOverlapRatio:.2,maxChunkSize:a?.maxToken||512,minChunkSize:100,autoChunkSize:a?.defaultToken||512,chunkSize:x,showChunkInput:!0,showPromptInput:!1,charsPointsPrice:a.charsPointsPrice,priceTip:l("core.dataset.import.Embedding Estimated Price Tips",{price:a.charsPointsPrice}),uploadRate:150},[r.g0.qa]:{chunkOverlapRatio:0,maxChunkSize:8e3,minChunkSize:3e3,autoChunkSize:.55*d.maxContext||6e3,chunkSize:.55*d.maxContext||6e3,showChunkInput:!1,showPromptInput:!0,charsPointsPrice:d.charsPointsPrice,priceTip:l("core.dataset.import.QA Estimated Price Tips",{price:d?.charsPointsPrice}),uploadRate:30}},f=(0,u.useMemo)(()=>T[P],[P]),g={[p.h.auto]:{chunkSize:f.autoChunkSize,customSplitChar:""},[p.h.custom]:{chunkSize:T[P].chunkSize,customSplitChar:w}},v=g[z].chunkSize,I={parentId:i,processParamsForm:k,...f,sources:S,setSources:C,chunkSize:v,importSource:e};return n.jsx(m.Provider,{value:I,children:o})});o()}catch(e){o(e)}})},22968:(e,t,i)=>{var o;i.d(t,{h:()=>o}),function(e){e.auto="auto",e.custom="custom"}(o||(o={}))}};